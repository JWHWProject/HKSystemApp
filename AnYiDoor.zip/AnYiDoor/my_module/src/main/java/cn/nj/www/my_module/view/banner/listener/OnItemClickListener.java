package cn.nj.www.my_module.view.banner.listener;

/**
 * Created by Sai on 15/11/13.
 */
public interface OnItemClickListener {
    public void onItemClick(int position);
}

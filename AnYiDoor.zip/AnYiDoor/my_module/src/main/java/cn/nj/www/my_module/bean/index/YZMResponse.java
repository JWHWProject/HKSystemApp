package cn.nj.www.my_module.bean.index;


import cn.nj.www.my_module.bean.BaseResponse;

public class YZMResponse extends BaseResponse
{
  
}

package cn.nj.www.my_module.tools;

import android.app.Activity;
import android.content.Context;
import android.webkit.JavascriptInterface;


/**
 * <webview中js交互>
 * <功能详细描述>
 *
 * @author Administrator
 * @version [版本号, 2015-8-12]
 * @see [相关类/方法]
 * @since [产品/模块版本]
 */
public class JavaScriptinterface
{
    private Context mContext;

    private Activity activity;

    public JavaScriptinterface(Context context)
    {
        mContext = context;
        activity = (Activity) context;
    }

    /**
     * 注册
     */
    @JavascriptInterface
    public void showregist()
    {

    }


    /**
     * 财富
     */
    @JavascriptInterface
    public void showMoneylist()
    {
//        Intent intentMoney = new Intent(mContext, MainAc.class);
//        intentMoney.putExtra(IntentCode.YUE_DETAIL_POP, IntentCode.YUE_DETAIL_POP_MONEY);
//        mContext.startActivity(intentMoney);
//        EventBus.getDefault().post(new NoticeEvent(NotiTag.TAG_MONEY_CHANGE));//每次刷新财富页面数据
    }



}
